// boilderplate code

const getNotes = async (req, res) => {
  // get all notes
};

const getNoteById = async (req, res) => {
  // get note by id
};

const createNote = async (req, res) => {
  // create note
};

const updateNote = async (req, res) => {
  // update note
};

const deleteNote = async (req, res) => {
  // delete note
};

export { createNote, deleteNote, getNoteById, getNotes, updateNote };
